<?php
return array(
	'read.php' => 'bbs/read/run',
	'pay/alipay.php' => 'bbs/alipay/run',
	'pay/paypal.php' => 'bbs/paypal/run',
	'pay/pay99bill.php' => 'bbs/pay99bill/run',
	'pay/tenpay.php' => 'bbs/tenpay/run',
);