<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'app_medal' => array('勋章管理', 'medal/medal/*', '', '', 'appcenter'), 
);