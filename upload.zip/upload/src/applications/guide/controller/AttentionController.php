<?php

/**
 * 用户引导-推荐关注
 *
 * @author xiaoxia.xu <x_824@sina.com>
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.windframework.com
 * @version $Id: AttentionController.php 5544 2012-03-06 09:55:31Z xiaoxia.xuxx $
 * @package src.modules.guide.controller
 */
class AttentionController extends PwBaseController {
	
	/* (non-PHPdoc)
	 * @see WindController::run()
	 */
	public function run() {
		
	}
}