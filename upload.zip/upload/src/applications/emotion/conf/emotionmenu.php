<?php
return array(
	'config_emotion' => array('表情管理', 'emotion/emotion/*', '', '', 'config', 'config_security'),
);