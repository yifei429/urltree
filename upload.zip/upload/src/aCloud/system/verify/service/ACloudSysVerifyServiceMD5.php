<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
class ACloudSysVerifyServiceMD5 {
	
	public function getFiles() {
		
	}
}